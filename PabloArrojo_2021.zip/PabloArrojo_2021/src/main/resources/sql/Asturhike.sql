CREATE TABLE IF NOT EXISTS `asturhike`.`usuarios` (
  `idusuario` INT NOT NULL AUTO_INCREMENT,
  `activo` INT NOT NULL,
  `correo` VARCHAR(255) NOT NULL,
  `nombreusuario` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`idusuario`),
  UNIQUE INDEX `UK_c31796xqt5blarvi8c0b9tnak` (`nombreusuario` ASC) VISIBLE);


CREATE TABLE IF NOT EXISTS `asturhike`.`categoria` (
  `idcategoria` INT NOT NULL AUTO_INCREMENT,
  `nombrecategoria` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`idcategoria`),
  UNIQUE INDEX `UK_6q2jmuarq0snax66gkoawk67j` (`nombrecategoria` ASC) VISIBLE);


CREATE TABLE IF NOT EXISTS `asturhike`.`categoria_usuario` (
  `id_usuario` INT NOT NULL,
  `id_categoria` INT NOT NULL,
  INDEX `FKigdsc4fpimeu2h6c7objsdfks` (`id_categoria` ASC) VISIBLE,
  INDEX `FKp17ha6gumgawnkthp4pycwgj8` (`id_usuario` ASC) VISIBLE,
  CONSTRAINT `FKigdsc4fpimeu2h6c7objsdfks`
    FOREIGN KEY (`id_categoria`)
    REFERENCES `asturhike`.`categoria` (`idcategoria`),
  CONSTRAINT `FKp17ha6gumgawnkthp4pycwgj8`
    FOREIGN KEY (`id_usuario`)
    REFERENCES `asturhike`.`usuarios` (`idusuario`));


CREATE TABLE IF NOT EXISTS `asturhike`.`publicacion` (
  `idpublicacion` INT NOT NULL AUTO_INCREMENT,
  `contenido` VARCHAR(255) NOT NULL,
  `fecha` DATETIME(6) NULL DEFAULT NULL,
  `titulo` VARCHAR(255) NOT NULL,
  `idusuario` INT NULL DEFAULT NULL,
  PRIMARY KEY (`idpublicacion`),
  INDEX `FK62xjwl90nsd07tw9kikvc8m0m` (`idusuario` ASC) VISIBLE,
  CONSTRAINT `FK62xjwl90nsd07tw9kikvc8m0m`
    FOREIGN KEY (`idusuario`)
    REFERENCES `asturhike`.`usuarios` (`idusuario`));

-- Usuarios
-- Contraseña sin encriptar: "password"
INSERT INTO usuarios (idusuario, nombreusuario, password, correo, activo)
VALUES
  (1, 'user','$2a$06$OAPObzhRdRXBCbk7Hj/ot.jY3zPwR8n7/mfLtKIgTzdJa4.6TwsIm', 'user@prueba.com', 1);
-- Contraseña sin encriptar: "password"
INSERT INTO usuarios (idusuario, nombreusuario, password, correo, activo)
VALUES
  (2, 'pabloprueba', '$2a$06$OAPObzhRdRXBCbk7Hj/ot.jY3zPwR8n7/mfLtKIgTzdJa4.6TwsIm', 'pablo@prueba.com',1);
-- Contraseña sin encriptar: "password"
INSERT INTO usuarios (idusuario, nombreusuario, password, correo, activo)
VALUES (3,'ana','$2a$06$OAPObzhRdRXBCbk7Hj/ot.jY3zPwR8n7/mfLtKIgTzdJa4.6TwsIm', 'ana@mail.com', 1);

-- Categorías
INSERT INTO categoria (idcategoria, nombrecategoria)
VALUES (1, 'ROLE_ADMIN');
INSERT INTO categoria (idcategoria, nombrecategoria)
VALUES (2, 'ROLE_USER');

-- Categorías de los usuarios
INSERT INTO categoria_usuario (id_usuario, id_categoria)
VALUES (1, 1);
INSERT INTO categoria_usuario (id_usuario, id_categoria)
VALUES (1, 2);
INSERT INTO categoria_usuario (id_usuario, id_categoria)
VALUES (2, 2);
INSERT INTO categoria_usuario (id_usuario, id_categoria)
VALUES (3, 2);

-- Publicaciones
INSERT INTO publicacion (idpublicacion, idusuario, titulo, contenido, fecha)
VALUES (1, 1, 'Primera publicación',
        '"Primera publicación en el blog"',
        {ts '2021-05-10 21:10:13.247'});
INSERT INTO publicacion (idpublicacion, idusuario, titulo, contenido, fecha)
VALUES (2, 1, 'Segunda publicación',
        '"Esta es la segunda publicación en el blog"',
        {ts '2021-05-10 21:10:13.247'});
INSERT INTO publicacion (idpublicacion, idusuario, titulo, contenido, fecha)
VALUES (3, 1, 'Tercera publicación',
        '"Esta es la tercera publicación en el blog"',
        CURRENT_TIMESTAMP());
    
