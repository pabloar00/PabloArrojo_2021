package com.dawes.repositorio;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dawes.modelo.PublicacionVO;
import com.dawes.modelo.UsuarioVO;

@Repository
public interface PublicacionRepositorio extends JpaRepository<PublicacionVO, Integer> {
	Page<PublicacionVO> findByAutorOrderByFechaDesc(UsuarioVO autor, Pageable pageable);
	Page<PublicacionVO> findAllByOrderByFechaDesc(Pageable pageable);
	PublicacionVO findById(int id);

}
