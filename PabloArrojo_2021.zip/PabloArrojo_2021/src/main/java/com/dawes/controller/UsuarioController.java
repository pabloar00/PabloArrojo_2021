package com.dawes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dawes.servicio.UsuarioServicio;



@Controller
public class UsuarioController {
	@Autowired
	UsuarioServicio us;
	
	

	
	@GetMapping("/usuarios")
	public String usuarios(Model modelo) {
		modelo.addAttribute("usuarios", us.findAll() );
		return "usuarios";
	}
	
	@GetMapping("/eliminarusuario")
	public String eliminar(@RequestParam int idusuario, Model modelo) {
		us.deleteById(idusuario);
		modelo.addAttribute("misusuarios", us.findAll());
		return "usuarios";
	}
	
}
