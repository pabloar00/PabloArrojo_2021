package com.dawes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.dawes.servicio.PublicacionServicio;
import com.dawes.servicio.UsuarioServicio;

@Controller
public class PrincipalController {

	@Autowired
	PublicacionServicio ps;
	
	@Autowired
	UsuarioServicio us;
	
	@GetMapping("/index")
	public String index(Model modelo) {
		modelo.addAttribute("publicaciones", ps.findAll());
		return "index";
	}
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	

	
}
