package com.dawes.controller;

import java.security.Principal;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dawes.modelo.PublicacionVO;
import com.dawes.modelo.UsuarioVO;
import com.dawes.servicio.PublicacionServicio;
import com.dawes.servicio.UsuarioServicio;



@Controller
public class PublicacionController {
	@Autowired
	PublicacionServicio ps;
	
	@Autowired
	UsuarioServicio us;
		
	@GetMapping("/insertarpublicacion")
	public String insertarpublicacion(Principal principal, Model modelo) {
		
		UsuarioVO usuarioexiste=us.findByNombreusuario(principal.getName());
		if(usuarioexiste !=null) {
			PublicacionVO publicacion=new PublicacionVO();
			publicacion.setAutor(usuarioexiste);
			modelo.addAttribute("publicacion", publicacion);
			return "insertarpublicacion";
		}
		return "error";	
		}

	@PostMapping("/submitpublicacion")
	public String submitpublicacion(@Valid PublicacionVO publicacion, BindingResult bindingResult) {
		if(bindingResult.hasErrors()) {
			return "insertarpublicacion";
		}else {
			ps.save(publicacion);
			return "redirect:/index";
		}
	}

	@GetMapping("/verpublicacion")
	public String publicacion(@RequestParam int idpublicacion, Model modelo) {
		PublicacionVO publicacion= ps.findById(idpublicacion);
		modelo.addAttribute("publicacion", publicacion);
		return "verpublicacion";
	}
	
	@GetMapping("/eliminarpublicacion")
	public String eliminar(@RequestParam int idpublicacion, Model modelo) {
		ps.deleteById(idpublicacion);
		modelo.addAttribute("publicaciones", ps.findAll());
		return "redirect:/index";
	}
	
	@GetMapping("/modificarpublicacion")
	public String modificar(@RequestParam int idpublicacion, Model modelo) {
		modelo.addAttribute("publicacion", ps.findById(idpublicacion));
		return "modificarpublicacion";
	}


	
	private boolean CreadorDePublicacion(Principal principal, PublicacionVO publicacion) {
		return principal !=null && principal.getName().equals(publicacion.getAutor().getNombreusuario());
	}
	
}
