package com.dawes.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.dawes.modelo.UsuarioVO;
import com.dawes.servicio.UsuarioServicio;

@Controller
public class SignUpController {

	@Autowired
	UsuarioServicio us;
	
	@GetMapping("/signup")
	public String signup(Model modelo) {
		modelo.addAttribute("usuario", new UsuarioVO());
		return "/signup";
	}
	
	@PostMapping("/signup")
	public String registro(@Valid UsuarioVO usuario, BindingResult bindingResult, Model modelo) {
		
		UsuarioVO correoexiste=us.findByCorreo(usuario.getCorreo());
		if(correoexiste !=null) {
			bindingResult.rejectValue("correo", "error.usuario", "Ya hay un usuario con ese correo, utiliza uno diferente");
		}
		UsuarioVO usuarioexiste=us.findByNombreusuario(usuario.getNombreusuario()); 
		if(usuarioexiste !=null){
			bindingResult.rejectValue("nombreusuario", "error.usuario", "Ya hay un usuario con ese nombre, utiliza uno diferente");
		}
		if(!bindingResult.hasErrors()) {
			us.save(usuario);
			modelo.addAttribute("mensajeOK", "Usuario registrado correctamente");
			modelo.addAttribute("usuario", new UsuarioVO());
		}
		
		return "signup";
	}
	

	
}
