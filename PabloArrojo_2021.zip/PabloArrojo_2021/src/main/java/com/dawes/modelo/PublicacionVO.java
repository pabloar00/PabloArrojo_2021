package com.dawes.modelo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;


@Entity
@Table(name="publicacion")
public class PublicacionVO {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idpublicacion")
	private int idpublicacion;
	
	@Column(name="titulo", nullable=false)
	private String titulo;
	
	@Column(name="contenido", nullable=false)
	private String contenido;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="fecha")
	@CreationTimestamp
	private Date fecha;
	
	@ManyToOne
	@JoinColumn(name="idusuario")
	private UsuarioVO autor;
	

	public PublicacionVO(int idpublicacion, String titulo, String contenido, Date fecha, UsuarioVO autor) {
		super();
		this.idpublicacion = idpublicacion;
		this.titulo = titulo;
		this.contenido = contenido;
		this.fecha = fecha;
		this.autor = autor;
	}

	public PublicacionVO() {
		super();
	}

	public int getIdpublicacion() {
		return idpublicacion;
	}

	public void setIdpublicacion(int idpublicacion) {
		this.idpublicacion = idpublicacion;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getContenido() {
		return contenido;
	}

	public void setContenido(String contenido) {
		this.contenido = contenido;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public UsuarioVO getAutor() {
		return autor;
	}

	public void setAutor(UsuarioVO autor) {
		this.autor = autor;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((autor == null) ? 0 : autor.hashCode());
		result = prime * result + ((contenido == null) ? 0 : contenido.hashCode());
		result = prime * result + ((fecha == null) ? 0 : fecha.hashCode());
		result = prime * result + idpublicacion;
		result = prime * result + ((titulo == null) ? 0 : titulo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PublicacionVO other = (PublicacionVO) obj;
		if (autor == null) {
			if (other.autor != null)
				return false;
		} else if (!autor.equals(other.autor))
			return false;
		if (contenido == null) {
			if (other.contenido != null)
				return false;
		} else if (!contenido.equals(other.contenido))
			return false;
		if (fecha == null) {
			if (other.fecha != null)
				return false;
		} else if (!fecha.equals(other.fecha))
			return false;
		if (idpublicacion != other.idpublicacion)
			return false;
		if (titulo == null) {
			if (other.titulo != null)
				return false;
		} else if (!titulo.equals(other.titulo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "PublicacionVO [idpublicacion=" + idpublicacion + ", titulo=" + titulo + ", contenido=" + contenido
				+ ", fecha=" + fecha + ", autor=" + autor + "]";
	}
	
	
	
}
