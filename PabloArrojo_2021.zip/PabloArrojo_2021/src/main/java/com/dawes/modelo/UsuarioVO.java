package com.dawes.modelo;

import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="usuarios")
public class UsuarioVO {
	
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		@Column(name="idusuario")
		private int idusuario;
		
		@Column(name="nombreusuario", nullable=false, unique=true)
		private String nombreusuario;
		
		@Column(name="password", nullable=false)
		private String password;
		
		@Column(name="correo", nullable=false)
		private String correo;
		
		@Column(name="activo", nullable=false)
		private int activo;
		

		@ManyToMany(fetch=FetchType.EAGER)
		@JoinTable(name="categoria_usuario",
			joinColumns = @JoinColumn(name="id_usuario"),
			inverseJoinColumns = @JoinColumn(name="id_categoria"))
		private Collection<CategoriaVO> categorias;
		
//		@OneToMany(mappedBy="usuarios")
//		private Collection<PublicacionVO> publicaciones;

		public UsuarioVO(int idusuario, String nombreusuario, String password, String correo, int activo,
				Collection<CategoriaVO> categorias, Collection<PublicacionVO> publicaciones) {
			super();
			this.idusuario = idusuario;
			this.nombreusuario = nombreusuario;
			this.password = password;
			this.correo = correo;
			this.activo = activo;
			this.categorias = categorias;
//			this.publicaciones = publicaciones;
		}

		public UsuarioVO() {
			super();
		}

		public int getIdusuario() {
			return idusuario;
		}

		public void setIdusuario(int idusuario) {
			this.idusuario = idusuario;
		}

		public String getNombreusuario() {
			return nombreusuario;
		}

		public void setNombreusuario(String nombreusuario) {
			this.nombreusuario = nombreusuario;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public String getCorreo() {
			return correo;
		}

		public void setCorreo(String correo) {
			this.correo = correo;
		}

		public int getActivo() {
			return activo;
		}

		public void setActivo(int activo) {
			this.activo = activo;
		}

		public Collection<CategoriaVO> getCategorias() {
			return categorias;
		}

		public void setCategorias(Collection<CategoriaVO> categorias) {
			this.categorias = categorias;
		}

//		public Collection<PublicacionVO> getPublicaciones() {
//			return publicaciones;
//		}

//		public void setPublicaciones(Collection<PublicacionVO> publicaciones) {
//			this.publicaciones = publicaciones;
//		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + activo;
			result = prime * result + ((categorias == null) ? 0 : categorias.hashCode());
			result = prime * result + ((correo == null) ? 0 : correo.hashCode());
			result = prime * result + idusuario;
			result = prime * result + ((nombreusuario == null) ? 0 : nombreusuario.hashCode());
			result = prime * result + ((password == null) ? 0 : password.hashCode());
//			result = prime * result + ((publicaciones == null) ? 0 : publicaciones.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			UsuarioVO other = (UsuarioVO) obj;
			if (activo != other.activo)
				return false;
			if (categorias == null) {
				if (other.categorias != null)
					return false;
			} else if (!categorias.equals(other.categorias))
				return false;
			if (correo == null) {
				if (other.correo != null)
					return false;
			} else if (!correo.equals(other.correo))
				return false;
			if (idusuario != other.idusuario)
				return false;
			if (nombreusuario == null) {
				if (other.nombreusuario != null)
					return false;
			} else if (!nombreusuario.equals(other.nombreusuario))
				return false;
			if (password == null) {
				if (other.password != null)
					return false;
			} else if (!password.equals(other.password))
				return false;
//			if (publicaciones == null) {
//				if (other.publicaciones != null)
//					return false;
//			} else if (!publicaciones.equals(other.publicaciones))
//				return false;
			return true;
		}

		@Override
		public String toString() {
			return "UsuarioVO [idusuario=" + idusuario + ", nombreusuario=" + nombreusuario + ", password=" + password
					+ ", correo=" + correo + ", activo=" + activo + ", categorias=" + categorias /*+ , publicaciones="
					+ publicaciones */+ "]";
		}

		
}
