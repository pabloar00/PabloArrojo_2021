package com.dawes.modelo;

import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="categoria")
public class CategoriaVO {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idcategoria")
	private int idcategoria;
	
	@Column(name="nombrecategoria", unique=true)
	private String nombrecategoria;
	


	public CategoriaVO(int idcategoria, String nombrecategoria) {
		super();
		this.idcategoria = idcategoria;
		this.nombrecategoria = nombrecategoria;
		
	}

	public CategoriaVO() {
		super();
	}

	public int getIdcategoria() {
		return idcategoria;
	}

	public void setIdcategoria(int idcategoria) {
		this.idcategoria = idcategoria;
	}

	public String getNombrecategoria() {
		return nombrecategoria;
	}

	public void setNombrecategoria(String nombrecategoria) {
		this.nombrecategoria = nombrecategoria;
	}





	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idcategoria;
		result = prime * result + ((nombrecategoria == null) ? 0 : nombrecategoria.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CategoriaVO other = (CategoriaVO) obj;
		if (idcategoria != other.idcategoria)
			return false;
		if (nombrecategoria == null) {
			if (other.nombrecategoria != null)
				return false;
		} else if (!nombrecategoria.equals(other.nombrecategoria))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RolVO [idcategoria=" + idcategoria + ", nombrecategoria=" + nombrecategoria + "]";
	}

	
	
	
	
	
}
