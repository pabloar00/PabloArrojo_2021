package com.dawes.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.dawes.servicioimpl.MiUserDetailsService;

@Configuration
@EnableWebSecurity
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter{

    @Autowired
    BCryptPasswordEncoder encoder;
    
    @Autowired
    MiUserDetailsService userdetails;
    
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception{
    	
    	auth
    		.userDetailsService(userdetails)
    		.passwordEncoder(encoder);
    }
 
    @Override
    protected void configure(HttpSecurity http) throws Exception{
    	
    	String loginPage= "/login";
    	String logoutPage= "/logout";
    	
    	http
    		.authorizeRequests()
    		.antMatchers("/index").permitAll()
    		.antMatchers(loginPage).permitAll()
    		.antMatchers("/signup").permitAll()
    		.antMatchers("/verpublicacion").permitAll()
    		.antMatchers("/insertarpublicacion").hasAnyRole("ADMIN", "USER")
    		.antMatchers("/modificarpublicacion").hasRole("ADMIN")
    		.antMatchers("/usuarios").hasRole("ADMIN")
    		.antMatchers("/modificarusuarios").hasRole("ADMIN")
    		.anyRequest()
    		.authenticated()
    		.and().csrf().disable()
    		.formLogin()
    		.loginPage(loginPage)
    		.loginPage("/login")
    		.failureUrl("/login?error=true")
    		.defaultSuccessUrl("/index")
    		.usernameParameter("nombreusuario")
    		.passwordParameter("password")
    		.and().logout()
    		.logoutRequestMatcher(new AntPathRequestMatcher(logoutPage))
    		.logoutSuccessUrl(loginPage).and().exceptionHandling();
 
    }
    
    @Override
    public void configure(WebSecurity web) throws Exception{
    	web
    		.ignoring()
    		.antMatchers("/resources/**", "/static/**", "/css/**");
    }
    
  
    

    

}
