package com.dawes.servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.dawes.modelo.CategoriaVO;
import com.dawes.modelo.UsuarioVO;

public interface UsuarioServicio {

	UsuarioVO findByNombreusuario(String nombreusuario);

	UsuarioVO findByCorreo(String correo);

	UsuarioVO save(UsuarioVO usuario);

	CategoriaVO findByNombrecategoria(String categoria);

	<S extends CategoriaVO> S save(S entity);

	<S extends CategoriaVO> Optional<S> findOne(Example<S> example);

	Page<CategoriaVO> findAll(Pageable pageable);

	List<CategoriaVO> findAll();

	List<CategoriaVO> findAll(Sort sort);

	List<CategoriaVO> findAllById(Iterable<Integer> ids);

	Optional<CategoriaVO> findById(Integer id);

	<S extends CategoriaVO> List<S> saveAll(Iterable<S> entities);

	void flush();

	<S extends CategoriaVO> S saveAndFlush(S entity);

	boolean existsById(Integer id);

	<S extends CategoriaVO> List<S> saveAllAndFlush(Iterable<S> entities);

	<S extends CategoriaVO> Page<S> findAll(Example<S> example, Pageable pageable);

	void deleteInBatch(Iterable<CategoriaVO> entities);

	<S extends CategoriaVO> long count(Example<S> example);

	<S extends CategoriaVO> boolean exists(Example<S> example);

	void deleteAllInBatch(Iterable<CategoriaVO> entities);

	long count();

	void deleteById(Integer id);

	void deleteAllByIdInBatch(Iterable<Integer> ids);

	void delete(CategoriaVO entity);

	void deleteAllById(Iterable<? extends Integer> ids);

	void deleteAllInBatch();

	CategoriaVO getOne(Integer id);

	void deleteAll(Iterable<? extends CategoriaVO> entities);

	void deleteAll();

	CategoriaVO getById(Integer id);

	<S extends CategoriaVO> List<S> findAll(Example<S> example);

	<S extends CategoriaVO> List<S> findAll(Example<S> example, Sort sort);

	Optional<UsuarioVO> findById(int id);
}