package com.dawes.servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.dawes.modelo.PublicacionVO;
import com.dawes.modelo.UsuarioVO;

public interface PublicacionServicio {

	PublicacionVO save(PublicacionVO publicacion);

	Page<PublicacionVO> findByUsuarioOrderedByFechaPageable(UsuarioVO usuario, int page);

	Page<PublicacionVO> findAllOrderedByFechaPageable(int page);

	void delete(PublicacionVO publicacion);

	Page<PublicacionVO> findByAutorOrderByFechaDesc(UsuarioVO autor, Pageable pageable);

	Page<PublicacionVO> findAllByOrderByFechaDesc(Pageable pageable);

	<S extends PublicacionVO> Optional<S> findOne(Example<S> example);

	Page<PublicacionVO> findAll(Pageable pageable);

	List<PublicacionVO> findAll();

	List<PublicacionVO> findAll(Sort sort);

	List<PublicacionVO> findAllById(Iterable<Integer> ids);

	Optional<PublicacionVO> findById(Integer id);

	<S extends PublicacionVO> List<S> saveAll(Iterable<S> entities);

	void flush();

	<S extends PublicacionVO> S saveAndFlush(S entity);

	boolean existsById(Integer id);

	<S extends PublicacionVO> List<S> saveAllAndFlush(Iterable<S> entities);

	<S extends PublicacionVO> Page<S> findAll(Example<S> example, Pageable pageable);

	void deleteInBatch(Iterable<PublicacionVO> entities);

	<S extends PublicacionVO> long count(Example<S> example);

	<S extends PublicacionVO> boolean exists(Example<S> example);

	void deleteAllInBatch(Iterable<PublicacionVO> entities);

	long count();

	void deleteById(Integer id);

	void deleteAllByIdInBatch(Iterable<Integer> ids);

	void deleteAllById(Iterable<? extends Integer> ids);

	void deleteAllInBatch();

	PublicacionVO getOne(Integer id);

	void deleteAll(Iterable<? extends PublicacionVO> entities);

	void deleteAll();

	PublicacionVO getById(Integer id);

	<S extends PublicacionVO> List<S> findAll(Example<S> example);

	<S extends PublicacionVO> List<S> findAll(Example<S> example, Sort sort);

	PublicacionVO findById(int id);
	
	


}