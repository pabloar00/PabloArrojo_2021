package com.dawes.servicioimpl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.dawes.modelo.CategoriaVO;
import com.dawes.modelo.UsuarioVO;
import com.dawes.servicio.UsuarioServicio;

@Service
public class MiUserDetailsService implements UserDetailsService {
	
	@Autowired
	UsuarioServicio us;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UsuarioVO usuario=us.findByNombreusuario(username);
		List<GrantedAuthority> authorities= getUserAuthority(usuario.getCategorias());
		return buildUserForAthentication(usuario, authorities);
	}

	private UserDetails buildUserForAthentication(UsuarioVO usuario, List<GrantedAuthority> authorities) {
		return new User(usuario.getNombreusuario(), usuario.getPassword(), authorities);
	}

	private List<GrantedAuthority> getUserAuthority(Collection<CategoriaVO> categorias) {
		Set<GrantedAuthority> roles=new HashSet<>();
		for(CategoriaVO rol: categorias) {
			roles.add(new SimpleGrantedAuthority(rol.getNombrecategoria()));
		}
		return new ArrayList<>(roles);
	}

}
