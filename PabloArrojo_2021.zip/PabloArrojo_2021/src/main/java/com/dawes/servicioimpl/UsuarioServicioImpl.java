package com.dawes.servicioimpl;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.dawes.modelo.CategoriaVO;
import com.dawes.modelo.UsuarioVO;
import com.dawes.repositorio.CategoriaRepositorio;
import com.dawes.repositorio.UsuarioRepositorio;
import com.dawes.servicio.UsuarioServicio;

@Service
public class UsuarioServicioImpl implements UsuarioServicio {

	private static final String USUARIO_CATEGORIA="ROLE_USER";
	
	@Autowired
	UsuarioRepositorio ur;
	
	@Autowired
	CategoriaRepositorio cr;
	
	@Autowired
	PasswordEncoder pe;

	@Override
	public UsuarioVO findByNombreusuario(String nombreusuario) {
		return ur.findByNombreusuario(nombreusuario);
	}

	@Override
	public UsuarioVO findByCorreo(String correo) {
		return ur.findByCorreo(correo);
	}

	@Override
	public UsuarioVO save(UsuarioVO usuario) {
		usuario.setPassword(pe.encode(usuario.getPassword()));
		usuario.setActivo(1);
		
		usuario.setCategorias(Collections.singletonList(cr.findByNombrecategoria(USUARIO_CATEGORIA)));
		return ur.saveAndFlush(usuario);
	}

	@Override
	public CategoriaVO findByNombrecategoria(String categoria) {
		return cr.findByNombrecategoria(categoria);
	}

	@Override
	public <S extends CategoriaVO> S save(S entity) {
		return cr.save(entity);
	}

	@Override
	public <S extends CategoriaVO> Optional<S> findOne(Example<S> example) {
		return cr.findOne(example);
	}

	@Override
	public Page<CategoriaVO> findAll(Pageable pageable) {
		return cr.findAll(pageable);
	}

	@Override
	public List<CategoriaVO> findAll() {
		return cr.findAll();
	}

	@Override
	public List<CategoriaVO> findAll(Sort sort) {
		return cr.findAll(sort);
	}

	@Override
	public List<CategoriaVO> findAllById(Iterable<Integer> ids) {
		return cr.findAllById(ids);
	}

	@Override
	public Optional<CategoriaVO> findById(Integer id) {
		return cr.findById(id);
	}

	@Override
	public <S extends CategoriaVO> List<S> saveAll(Iterable<S> entities) {
		return cr.saveAll(entities);
	}

	@Override
	public void flush() {
		cr.flush();
	}

	@Override
	public <S extends CategoriaVO> S saveAndFlush(S entity) {
		return cr.saveAndFlush(entity);
	}

	@Override
	public boolean existsById(Integer id) {
		return cr.existsById(id);
	}

	@Override
	public <S extends CategoriaVO> List<S> saveAllAndFlush(Iterable<S> entities) {
		return cr.saveAllAndFlush(entities);
	}

	@Override
	public <S extends CategoriaVO> Page<S> findAll(Example<S> example, Pageable pageable) {
		return cr.findAll(example, pageable);
	}

	@Override
	public void deleteInBatch(Iterable<CategoriaVO> entities) {
		cr.deleteInBatch(entities);
	}

	@Override
	public <S extends CategoriaVO> long count(Example<S> example) {
		return cr.count(example);
	}

	@Override
	public <S extends CategoriaVO> boolean exists(Example<S> example) {
		return cr.exists(example);
	}

	@Override
	public void deleteAllInBatch(Iterable<CategoriaVO> entities) {
		cr.deleteAllInBatch(entities);
	}

	@Override
	public long count() {
		return cr.count();
	}

	@Override
	public void deleteById(Integer id) {
		cr.deleteById(id);
	}

	@Override
	public void deleteAllByIdInBatch(Iterable<Integer> ids) {
		cr.deleteAllByIdInBatch(ids);
	}

	@Override
	public void delete(CategoriaVO entity) {
		cr.delete(entity);
	}

	@Override
	public void deleteAllById(Iterable<? extends Integer> ids) {
		cr.deleteAllById(ids);
	}

	@Override
	public void deleteAllInBatch() {
		cr.deleteAllInBatch();
	}

	@Override
	public CategoriaVO getOne(Integer id) {
		return cr.getOne(id);
	}

	@Override
	public void deleteAll(Iterable<? extends CategoriaVO> entities) {
		cr.deleteAll(entities);
	}

	@Override
	public void deleteAll() {
		cr.deleteAll();
	}

	@Override
	public CategoriaVO getById(Integer id) {
		return cr.getById(id);
	}

	@Override
	public <S extends CategoriaVO> List<S> findAll(Example<S> example) {
		return cr.findAll(example);
	}

	@Override
	public <S extends CategoriaVO> List<S> findAll(Example<S> example, Sort sort) {
		return cr.findAll(example, sort);
	}

	@Override
	public Optional<UsuarioVO> findById(int id) {
		return ur.findById(id);
	}
	
	
	
	
}
