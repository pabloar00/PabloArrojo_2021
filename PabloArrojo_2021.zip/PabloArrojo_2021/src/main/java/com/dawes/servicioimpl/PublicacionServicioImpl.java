package com.dawes.servicioimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.dawes.modelo.PublicacionVO;
import com.dawes.modelo.UsuarioVO;
import com.dawes.repositorio.PublicacionRepositorio;
import com.dawes.servicio.PublicacionServicio;

@Service
public class PublicacionServicioImpl implements PublicacionServicio {

	@Autowired
	PublicacionRepositorio pr;

	@Override
	public PublicacionVO save(PublicacionVO publicacion) {
		return pr.saveAndFlush(publicacion);
	}

	@Override
	public Page<PublicacionVO> findByUsuarioOrderedByFechaPageable(UsuarioVO usuario, int page) {
		return pr.findByAutorOrderByFechaDesc(usuario, PageRequest.of(subtractPageByOne(page),5));
	}

	@Override
	public Page<PublicacionVO> findAllOrderedByFechaPageable(int page) {
		return pr.findAllByOrderByFechaDesc(PageRequest.of(subtractPageByOne(page), 5));
	}

	@Override
	public void delete(PublicacionVO publicacion) {
		pr.delete(publicacion);
	}
	
	private int subtractPageByOne(int page) {
		return(page<1) ? 0 : page - 1;
	}

	@Override
	public Page<PublicacionVO> findByAutorOrderByFechaDesc(UsuarioVO autor, Pageable pageable) {
		return pr.findByAutorOrderByFechaDesc(autor, pageable);
	}

	@Override
	public Page<PublicacionVO> findAllByOrderByFechaDesc(Pageable pageable) {
		return pr.findAllByOrderByFechaDesc(pageable);
	}


	@Override
	public <S extends PublicacionVO> Optional<S> findOne(Example<S> example) {
		return pr.findOne(example);
	}

	@Override
	public Page<PublicacionVO> findAll(Pageable pageable) {
		return pr.findAll(pageable);
	}

	@Override
	public List<PublicacionVO> findAll() {
		return pr.findAll();
	}

	@Override
	public List<PublicacionVO> findAll(Sort sort) {
		return pr.findAll(sort);
	}

	@Override
	public List<PublicacionVO> findAllById(Iterable<Integer> ids) {
		return pr.findAllById(ids);
	}

	@Override
	public Optional<PublicacionVO> findById(Integer id) {
		return pr.findById(id);
	}

	@Override
	public <S extends PublicacionVO> List<S> saveAll(Iterable<S> entities) {
		return pr.saveAll(entities);
	}

	@Override
	public void flush() {
		pr.flush();
	}

	@Override
	public <S extends PublicacionVO> S saveAndFlush(S entity) {
		return pr.saveAndFlush(entity);
	}

	@Override
	public boolean existsById(Integer id) {
		return pr.existsById(id);
	}

	@Override
	public <S extends PublicacionVO> List<S> saveAllAndFlush(Iterable<S> entities) {
		return pr.saveAllAndFlush(entities);
	}

	@Override
	public <S extends PublicacionVO> Page<S> findAll(Example<S> example, Pageable pageable) {
		return pr.findAll(example, pageable);
	}

	@Override
	public void deleteInBatch(Iterable<PublicacionVO> entities) {
		pr.deleteInBatch(entities);
	}

	@Override
	public <S extends PublicacionVO> long count(Example<S> example) {
		return pr.count(example);
	}

	@Override
	public <S extends PublicacionVO> boolean exists(Example<S> example) {
		return pr.exists(example);
	}

	@Override
	public void deleteAllInBatch(Iterable<PublicacionVO> entities) {
		pr.deleteAllInBatch(entities);
	}

	@Override
	public long count() {
		return pr.count();
	}

	@Override
	public void deleteById(Integer id) {
		pr.deleteById(id);
	}

	@Override
	public void deleteAllByIdInBatch(Iterable<Integer> ids) {
		pr.deleteAllByIdInBatch(ids);
	}

	@Override
	public void deleteAllById(Iterable<? extends Integer> ids) {
		pr.deleteAllById(ids);
	}

	@Override
	public void deleteAllInBatch() {
		pr.deleteAllInBatch();
	}

	@Override
	public PublicacionVO getOne(Integer id) {
		return pr.getOne(id);
	}

	@Override
	public void deleteAll(Iterable<? extends PublicacionVO> entities) {
		pr.deleteAll(entities);
	}

	@Override
	public void deleteAll() {
		pr.deleteAll();
	}

	@Override
	public PublicacionVO getById(Integer id) {
		return pr.getById(id);
	}

	@Override
	public <S extends PublicacionVO> List<S> findAll(Example<S> example) {
		return pr.findAll(example);
	}

	@Override
	public <S extends PublicacionVO> List<S> findAll(Example<S> example, Sort sort) {
		return pr.findAll(example, sort);
	}

	

	@Override
	public PublicacionVO findById(int id) {
		return pr.findById(id);
	}

	
}
