package com.dawes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsturhikeApplicationTests {

	@Test
	void contextLoads() {
	}

}
